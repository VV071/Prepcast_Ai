import { supabase } from '../supabaseClient';
import { logActivity } from './sessionService';

/**
 * ============================================
 * COLLABORATORS SERVICE
 * ============================================
 * Manage session collaborators and permissions
 */

/**
 * Retrieves collaborators for a session.
 * @param {string} sessionId - The UUID of the session.
 * @returns {Promise<Array>} List of collaborators.
 */
export const getCollaborators = async (sessionId) => {
    const { data, error } = await supabase
        .from('session_collaborators')
        .select(`
      *,
      user:user_profiles(first_name, last_name, email, avatar_url)
    `)
        .eq('session_id', sessionId);

    if (error) throw error;
    return data;
};

/**
 * Adds a collaborator to a session.
 * @param {string} sessionId - The UUID of the session.
 * @param {string} email - The email of the user to invite.
 * @param {string} invitedBy - The UUID of the user sending the invite.
 * @param {string} permissionLevel - Permission level ('viewer', 'editor', 'admin').
 * @returns {Promise<Object>} The created collaborator record.
 */
export const addCollaborator = async (sessionId, email, invitedBy, permissionLevel = 'viewer') => {
    // 1. Find user by email
    const { data: userData, error: userError } = await supabase
        .from('users')
        .select('id')
        .eq('email', email)
        .single();

    if (userError || !userData) {
        throw new Error(`User with email ${email} not found.`);
    }

    const userId = userData.id;

    // 2. Add to session_collaborators
    const { data, error } = await supabase
        .from('session_collaborators')
        .insert([{
            session_id: sessionId,
            user_id: userId,
            invited_by: invitedBy,
            permission_level: permissionLevel,
            invitation_status: 'pending'
        }])
        .select()
        .single();

    if (error) throw error;

    // Log activity
    await logActivity(sessionId, invitedBy, 'collaborator_added', `Invited ${email} as ${permissionLevel}`);

    return data;
};

/**
 * Removes a collaborator from a session.
 * @param {string} collaboratorId - The UUID of the collaborator record.
 * @param {string} removedBy - The UUID of the user performing the removal.
 * @returns {Promise<boolean>} True if successful.
 */
export const removeCollaborator = async (collaboratorId, removedBy) => {
    // Get session_id for logging before deletion
    const { data: collabData } = await supabase
        .from('session_collaborators')
        .select('session_id, user_id')
        .eq('id', collaboratorId)
        .single();

    const { error } = await supabase
        .from('session_collaborators')
        .delete()
        .eq('id', collaboratorId);

    if (error) throw error;

    if (collabData) {
        await logActivity(collabData.session_id, removedBy, 'collaborator_removed', 'Removed collaborator');
    }

    return true;
};
